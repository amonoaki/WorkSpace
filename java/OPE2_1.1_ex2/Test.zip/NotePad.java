public class NotePad extends Computer
{
    private int gps = 10;
    public void navigate() {
        System.out.println("gps:" + gps);
    }
}
