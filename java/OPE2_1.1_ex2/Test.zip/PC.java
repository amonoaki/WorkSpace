public class PC extends Computer
{
    private String keyboard = "DELL����";
    public void game() {
        System.out.println("keyboard: " + keyboard);
    }
}
