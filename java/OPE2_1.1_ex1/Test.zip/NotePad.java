public class NotePad extends Computer
{
    int gps = 10;
    public void navigate() {
        System.out.println("gps:" + gps);
    }
}
