public class PC extends Computer
{
    String keyboard = "DELL����";
    public void game() {
        System.out.println("keyboard: " + keyboard);
    }
}
