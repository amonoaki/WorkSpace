public class Test
{
    public static void main(String [] args) {
        PC pc = new PC();
        System.out.println(pc.getDetails());
    }
}
